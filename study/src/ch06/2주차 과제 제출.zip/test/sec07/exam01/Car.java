package ch06.test.sec07.exam01;

public class Car {
    String name;
    String color;
    int speed;

    Car(String name, String color, int speed) {
        this.name = name;
        this.color = color;
        this.speed = speed;
    }
}
